. /opt/ros/vision_opencv/setup.sh
